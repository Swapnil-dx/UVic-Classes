/******************************************************************************
 *  Compilation:  javac Prim.java
 *  Execution:    java Prim filename.txt
 *  Dependencies: EdgeWeightedGraph.java Edge.java
 *                IndexMinPQ.java UF.java In.java StdOut.java
 *  Data files:   http://algs4.cs.princeton.edu/43mst/tinyEWG.txt
 *                http://algs4.cs.princeton.edu/43mst/mediumEWG.txt
 *                http://algs4.cs.princeton.edu/43mst/largeEWG.txt
 *
 *  Compute a minimum spanning tree using Prim's algorithm.
 *
 *  %  java Prim tinyEWG.txt 
 *  1-7 0.19000
 *  0-2 0.26000
 *  2-3 0.17000
 *  4-5 0.35000
 *  5-7 0.28000
 *  6-2 0.40000
 *  0-7 0.16000
 *  1.81000
 *
 *  % java Prim mediumEWG.txt
 *  1-72   0.06506
 *  2-86   0.05980
 *  3-67   0.09725
 *  4-55   0.06425
 *  5-102  0.03834
 *  6-129  0.05363
 *  7-157  0.00516
 *  ...
 *  10.46351
 *
 *  % java Prim largeEWG.txt
 *  ...
 *  647.66307
 *
 ******************************************************************************/

package lab4;

public class Prim {
    private Edge[] edgeTo;        // edgeTo[v] = shortest edge from tree vertex to non-tree vertex
    private double[] distTo;      // distTo[v] = weight of shortest such edge
    private boolean[] marked;     // marked[v] = true if v on tree, false otherwise
    private IndexMinPQ<Double> pq;

    /**
     * Compute a minimum spanning tree of an edge-weighted graph.
     * @param G the edge-weighted graph
     */
    public Prim(EdgeWeightedGraph G) {
	// initialize your data structures here and do other setup

	/* write code for Prim's algorithm (or call a method you
	   created for executing the algorithm) */
    }




    /**
     * Returns the sum of the edge weights in a minimum spanning tree
     * @return the sum of the edge weights in a minimum spanning tree
     */
    public double weight() {
	double weight = 0.0;
	for (int v = 0; v < edgeTo.length; v++) {
            Edge e = edgeTo[v];
            if (e != null) {
		weight += e.weight();
            }
        }
        return weight;
    }



    /**
     * Unit tests the {@code Prim} data type.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        In in = new In(args[0]);
        EdgeWeightedGraph G = new EdgeWeightedGraph(in);
        Prim mst = new Prim(G);

	// print the MST
	for (int v = 0; v < mst.edgeTo.length; v++) {
            Edge e = mst.edgeTo[v];
            if (e != null) {
		StdOut.println(e);
            }
        }
	// and print its weight
        StdOut.printf("%.5f\n", mst.weight());
    }


}

/******************************************************************************
 *  Copyright 2002-2016, Robert Sedgewick and Kevin Wayne.
 *
 *  This file is part of algs4.jar, which accompanies the textbook
 *
 *      Algorithms, 4th edition by Robert Sedgewick and Kevin Wayne,
 *      Addison-Wesley Professional, 2011, ISBN 0-321-57351-X.
 *      http://algs4.cs.princeton.edu
 *
 *
 *  algs4.jar is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  algs4.jar is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with algs4.jar.  If not, see http://www.gnu.org/licenses.
 ******************************************************************************/
