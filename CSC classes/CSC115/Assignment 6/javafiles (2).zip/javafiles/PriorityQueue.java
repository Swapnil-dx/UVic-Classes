import java.util.NoSuchElementException;



public class PriorityQueue<E extends Comparable<E>> {
	
	private Heap<E>  heap;

	public PriorityQueue() {
 	/********  COMPLETE *******/
	}

 	/********  COMPLETE *******/
			
}
	
