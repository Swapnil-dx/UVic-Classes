#!/bin/bash

set -x #echo on

javac lab4/In.java
javac lab4/StdOut.java
javac lab4/StdIn.java
javac lab4/StdRandom.java
javac lab4/Bag.java
javac lab4/Edge.java
javac lab4/EdgeWeightedGraph.java
javac lab4/Stack.java
javac lab4/IndexMinPQ.java

# Once the above lines have been executed, you only need to call the command on the next two lines each time you want to compile and run Prim
# javac lab4/Prim.java
# java lab4/Prim
